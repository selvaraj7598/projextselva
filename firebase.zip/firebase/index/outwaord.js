const companyname=document.getElementById('cname');
const date=document.getElementById('date');

const stylno=document.getElementById('styleno');
const size=document.getElementById('size');
const quan=document.getElementById('quan');
const btnadd=document.getElementById('add');
const btnok=document.getElementById('save');
var total = document.getElementById('total');
const colour=document.getElementById('clour')
const dname=document.getElementById('dname');
const buyer=document.getElementById('buyer');
const bundles = document.getElementById('bundle')
const sdc=document.getElementById('sdcno')
const btnaddclr=document.getElementById('save1')
var totalsizeQty,totalsizeQty2,totalsizeQty1,total=0;var count1,count2;
var balance;
var balance1=0;
const create=document.getElementById('create')
const gen=document.getElementById('generate')
var emb = document.getElementById('mis1');
var fab = document.getElementById('mis2');
var i=0;
var dcno
var flag;
function printDiv() {
    var divContents = document.getElementById("generate").innerHTML;
    var a = window.open('', '', 'height=500, width=500');
    
    a.document.write('<html><body><style>');
            
            a.document.write(divContents);
            a.document.write('</style></body></html>');
            a.document.close();
            a.print();
            a.document.write('<html><body><style>');
            
            
}


function a()
{
    debugger
    document.getElementById('text').innerHTML=(companyname.value).toUpperCase();
    var companyname1 = (companyname.value).toUpperCase();
    
        firebase.database().ref(companyname1).on('value',(snapshot)=>{
            snapshot.forEach((data) => {
                key=data.val();
             uservalue=data.val();
               document.getElementById('text1').innerHTML=(uservalue.useraddress);
            })
        })
}
function d()
{
    debugger
    var d = new Date(date.value);
  var n = d.getDate();
  var m=d.getMonth()+1;var l= d.getFullYear()
  
    document.getElementById('text2').innerHTML='DATE :- '+n+"/"+m+"/"+l;
}
function f()
{
    document.getElementById('text3').innerHTML='BUYER :- '+(buyer.value).toUpperCase();
}

function g()
{
    document.getElementById('text4').innerHTML='STYLE NO :- '+stylno.value;
}

function clr()
{
    document.getElementById('text7').innerHTML='STYLE NO :- '+(colour.value).toUpperCase();
}

function h()
{
    document.getElementById('text6').innerHTML='DESIGN NAME :- '+(dname.value).toUpperCase();
}

function sdcn()
{
    document.getElementById('text8').innerHTML='SUPPLIER DCNO :- '+sdc.value;
}

function p()
{
    document.getElementById('text12').innerHTML=typ.value;
}
function emb_mis()
{
    document.getElementById('text16').innerHTML="Emb_Mistakes :- "+emb.value;
}
function fab_mis()
{
    document.getElementById('text17').innerHTML='Fab_Maistake :- '+fab.value;
}


function add()
{
    
 firebase.database().ref('out/'+stylno.value+colour.value+dcno).push({
        userclour : colour.value,
        usersize : size.value,
        userquan : quan.value,
}).then(()=>{
    debugger
    var row2 = document.getElementById("size1");
    var row3 = document.getElementById("quantity");
    var row4 = document.getElementById("bun")
    row2.innerHTML += "<td>"+(size.value).toUpperCase()+"</td>";
    row3.innerHTML += "<td>"+quan.value+"</td>";
    row4.innerHTML += "<td>"+bundles.value+"</td>";
                // create1.innerHTML += "<tr><td>"+colour.value+"</td></tr>"
                // create2.innerHTML += "<tr><td>"+size.value+"</td></tr>"
                // create3.innerHTML += "<tr><td>"+quan.value+"</td></tr>"

                    
        
            
        })
                 totalsizeQty=0;
            var leadsRef =firebase.database().ref('out/'+stylno.value+colour.value+dcno);
            leadsRef.on('value', function(snapshot) {
                snapshot.forEach(function(childSnapshot) {
                  var childData = childSnapshot.val();
                  console.log(childData+"");
                  //uservalue=childData.val();
                  totalsizeQty=totalsizeQty+parseInt(childData.userquan);
                  
        
            })
            document.getElementById('text11').innerHTML='GOOD PIECES :- '+totalsizeQty
            
            })
            var total_pcs=totalsizeQty+parseInt(emb.value)+parseInt(fab.value);
    document.getElementById('text12').innerHTML=' TOTAL QUANTITY :- '+total_pcs

}  

function addclr()
{
    
     
    firebase.database().ref('out/'+stylno.value+ colour.value).push({
        usertotal : totalsizeQty,
    }) 
    
    totalsizeQty1=0;
    var leadsRef = firebase.database().ref('out/'+stylno.value+colour.value);
    leadsRef.on('value', function(snapshot) {
        snapshot.forEach(function(childSnapshot) {
          var childData = childSnapshot.val();
          console.log(childData+"");
          //uservalue=childData.val();
          totalsizeQty1=totalsizeQty1+parseInt(childData.usertotal);
          count1=totalsizeQty1
          
    })
    
})

              totalsizeQty2=0
              var leadsRef1 = firebase.database().ref('in/'+stylno.value+colour.value);
        leadsRef1.on('value', function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
              var childData = childSnapshot.val();
              console.log(childData+"");
              //uservalue=childData.val();
              totalsizeQty2=totalsizeQty2+parseInt(childData.usertotal);
              count2=totalsizeQty2
              
             })

             var balance=count2-count1

                 alert('balance :- '+balance)
             
             
        })
}    



btnadd.addEventListener('click',function(event)
{
   
    event.preventDefault();
    add()
    

})
btnok.addEventListener('click',function (event) 
{
    event.preventDefault();
    firebase.database().ref("user").push({
        usercompany : companyname.value
    })
    firebase.database().ref('user').on('value',(snapshot)=>{
        
        var num=snapshot.numChildren();
        dcno=num+1;
        document.getElementById('text14').innerHTML='DC NO :- '+dcno
        })
        
    
});
btnaddclr.addEventListener('click',function (event) 
{
    event.preventDefault();
    addclr();    
});


const email=document.getElementById('email');
const pass= document.getElementById('pass');
const submit=document.getElementById('submit');

submit.onclick =() =>{
  var e=email.value;
  var p=pass.value;
firebase.auth().signInWithEmailAndPassword(e, p)
  .then(() => {


window.location.href="main.html"
  
    
  })
  .catch((error) => {
     alert('enter valid mail id or password');
  });
}
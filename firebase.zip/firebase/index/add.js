const companyname = document.getElementById('cname');

const address = document.getElementById('add');
function save()
{


firebase.database().ref(companyname.value).push({
    useraddress:address.value
})
}
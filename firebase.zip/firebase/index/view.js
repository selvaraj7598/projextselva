function view1()
{
    window.location.href='btnview.html'
}
const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');
const email=document.getElementById('email');
const pass=document.getElementById('pass');


signInButton.addEventListener('click', () => {
    
});
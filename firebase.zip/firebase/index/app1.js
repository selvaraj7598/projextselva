const companyname=document.getElementById('cname');
const style=document.getElementById('styl')
const clrdeatils=document.getElementById('clrdetails');
const shade=document.getElementById('shade');
const buyer = document.getElementById('buyer');
const dname = document.getElementById('dname');
const stitches = document.getElementById('stitches')
const nsize=document.getElementById('nsize');
const fdetails=document.getElementById('fdetails');
const arate=document.getElementById('arate');
const buttonadd=document.getElementById('add');
const usershow=document.getElementById('show');
function generatepdf()
{
    const gen=document.getElementById('generate');
    html2pdf().from(gen).save('output.pdf')
    
    
}
var Imgname,Imgurl;
var files=[];
var reader;
document.getElementById('select').onclick=function(e){
    var input;
    var input=document.createElement('input');
    input.type= 'file';
    input.click();
    input.onchange = e =>{
        
        files = e.target.files;
        reader=new FileReader();
        reader.onload = function()
        {
            document.getElementById('myimg').src=reader.result;
        }
        reader.readAsDataURL(files[0])
    }
    input.click();
}
document.getElementById('upload').onclick=function(){
    Imgname=document.getElementById('namebox').value
    var uploadTask=firebase.storage().ref('Images/'+Imgname+'.png').put(files[0]);

    uploadTask.on('state_changed',function(snapshot)
    {
        var progress = (snapshot.bytesTransfered / snapshot.totalBytes)*100;
        
    },

    function(error)
    {
        alert('Error in Saving the image');
    },

    function()
    {
        uploadTask.snapshot.ref.getDownloadURL().then(function(url)
        {
            ImgUrl = url;
        })

        firebase.database().ref('pictures/'+Imgname).set(
            {
                Name : Imgname,
                Link : Imgurl
            }
        )
        alert('image added successfully');
    }
    )

}

function a() {
    document.getElementById('text1').innerHTML='Company Name :- '+(cname.value).toUpperCase();
}
function s() {
    document.getElementById('text2').innerHTML='Style No:- '+(style.value);
}
function d() {
    document.getElementById('text3').innerHTML='Buyer :- &nbsp'+(buyer.value).toUpperCase();
}
function f() {
    document.getElementById('text4').innerHTML='Design Name :-  '+(dname.value).toUpperCase();
}
function g() {
    document.getElementById('text5').innerHTML='Stitches :-  '+stitches.value;
}
function h() {
    document.getElementById('text6').innerHTML='Colour Details :-  '+(clrdeatils.value).toUpperCase();
}
function j() {
    document.getElementById('text7').innerHTML='Shade :-  '+shade.value;
}
function k() {
    document.getElementById('text8').innerHTML='Needle Size :- '+nsize.value;
}
function l() {
    document.getElementById('text9').innerHTML='Foam Details :-'+(fdetails.value);
}
function p() {
    document.getElementById('text0').innerHTML='Approximate Rate :-'+ arate.value;
}



    function add()
    {
        firebase.database().ref('sam/'+style.value).push(
            {
                
                userclrdeatils:clrdeatils.value,
                usershade:shade.value,
             });
             firebase.database().ref('sam/'+style.value).on('value',(snapshot)=>{
                var i=1;
                usershow.innerHTML ="";
                snapshot.forEach((data) => {
                    key=data.val();
                    uservalue=data.val();
                    uservalue=data.val();
                    
                    usershow.innerHTML +=`<tr>
                    <td>${i}</td>
                    <td>${uservalue.userclrdeatils}</td>
                    <td>${uservalue.usershade}</td>
                    </tr>`;
                    i++;
                });
            });
            
    }
    function functionsave()
    {
        firebase.database().ref('sam/'+companyname.value).push
        ({
         
            
            userstyle : style.value,
            ubuyer : buyer.value,
            udname : dname.value,
            ustitches : stitches.value,
            unsize : nsize.value,
            ufdetails : fdetails.value,
            uarate : arate.value
           

        });
    }

    buttonadd.addEventListener('click',function(event)

 {
       
    event.preventDefault();
    add();
   
});


document.getElementById('save').addEventListener('click',function(event)
    
    {
        event.preventDefault();
        functionsave();
    });
   

const save=document.getElementById('add');
const companyname=document.getElementById('cname')

function printDiv() {
    var divContents = document.getElementById("generate1").innerHTML;
    var a = window.open('', '', 'height=500, width=500');
    
    a.document.write('<html>');
            
            a.document.write(divContents);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
}


var Imgname,Imgurl;
var files=[];
var reader;
document.getElementById('select').onclick=function(e){
    var input;
    var input=document.createElement('input');
    input.type= 'file';
    input.click();
    input.onchange = e =>{
        
        files = e.target.files;
        reader=new FileReader();
        reader.onload = function()
        {
            document.getElementById('myimg').src=reader.result;
        }
        reader.readAsDataURL(files[0])
    }
    input.click();
}
document.getElementById('upload').onclick=function(){
    Imgname=document.getElementById('namebox').value
    var uploadTask=firebase.storage().ref('Images/'+Imgname+'.png').put(files[0]);

    uploadTask.on('state_changed',function(snapshot)
    {
        var progress = (snapshot.bytesTransfered / snapshot.totalBytes)*100;
        
    },

    function(error)
    {
        alert('Error in Saving the image');
    },

    function()
    {
        uploadTask.snapshot.ref.getDownloadURL().then(function(url)
        {
            ImgUrl = url;
        })

        firebase.database().ref('pictures/'+Imgname).set(
            {
                Name : Imgname,
                Link : Imgurl
            }
        )
        alert('image added successfully');
    }
    )

}





function a()
{
    document.getElementById('text1').innerHTML='TO M/S :- '+(companyname.value).toUpperCase()
}
function b()
{
    document.getElementById('text2').innerHTML=(document.getElementById('dname').value).toUpperCase()
}
function c()
{
    document.getElementById('text3').innerHTML=(document.getElementById('stylno').value).toUpperCase()
}
function d()
{
    document.getElementById('text4').innerHTML=(document.getElementById('nclrs').value).toUpperCase()
}
function e()
{
    document.getElementById('text5').innerHTML=(document.getElementById('Stitches').value).toUpperCase()
}
function f()
{
    document.getElementById('text6').innerHTML=(document.getElementById('noa').value).toUpperCase()
}


function h()
{
    document.getElementById('text8').innerHTML=(document.getElementById('Rps').value).toUpperCase()
}
function i()
{
    document.getElementById('text9').innerHTML=(document.getElementById('Ac').value).toUpperCase()
}
function j()
{
    document.getElementById('text10').innerHTML=(document.getElementById('rp').value).toUpperCase()
}
function l()
{
    document.getElementById('text11').innerHTML=(document.getElementById('oq').value).toUpperCase()
}
function m()
{
    document.getElementById('text12').innerHTML=(document.getElementById('pd').value).toUpperCase()
}





function add(){
    
    firebase.database().ref("ratequotation").push({
        usercompany : companyname.value
    })
    firebase.database().ref('ratequotation').on('value',(snapshot)=>{
        
        var num=snapshot.numChildren();
        dcno=num+1000;
        document.getElementById('text14').innerHTML='DC NO :- '+dcno
        })
        
    
}

    

// afzal jajaja


 




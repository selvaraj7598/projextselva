const companyname=document.getElementById('clr').toUpperCase();
const stylno=document.getElementById('styleno');
const save=document.getElementById('save');
var totalsizeQty=0;
var totalsizeQty1=0;

function view()
{
 
firebase.database().ref('in'+stylno.value+companyname.value).on('value',(snapshot)=>{
        
   

        
    snapshot.forEach((data) => {
        
        key=data.val();
        uservalue=data.val();
        create.innerHTML +=`<tr>
                
        <td>${uservalue.userdate}</td>
        <td>${uservalue.userclr}</td>
        <td>${uservalue.usertotal}</td>      
        
        
        </tr>`;
    
 })
})

firebase.database().ref('out'+stylno.value+companyname.value).on('value',(snapshot)=>{
        
    

        
    snapshot.forEach((data) => {
        create1.innerHTML = ''
        key=data.val();
        uservalue=data.val();
        create1.innerHTML +=`<tr>
                
                
        <td>${uservalue.userdate}</td>
        <td>${uservalue.userclr}</td>
        <td>${uservalue.usertotal}</td>
        
        
        </tr>`;
    
 })
})
 var leadsRef =firebase.database().ref('in'+stylno.value+companyname.value);
leadsRef.on('value', function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      var childData = childSnapshot.val();
      console.log(childData+"");
      //uservalue=childData.val();
      totalsizeQty=totalsizeQty+parseInt(childData.userquan);
      

})
})
 var leadsRef1=firebase.database().ref('out'+stylno.value+companyname.value);
leadsRef.on('value', function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
      var childData = childSnapshot.val();
      console.log(childData+"");
      //uservalue=childData.val();
      totalsizeQty1=totalsizeQty1+parseInt(childData.userquan);
      

})
})

var Total = totalsizeQty-totalsizeQty1;
document.getElementById('text1').innerHTML=Total;
}


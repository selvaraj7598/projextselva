const companyname=document.getElementById('cname');
const date=document.getElementById('date');
const dcno=document.getElementById('dcno');
const stylno=document.getElementById('stylno');
const size=document.getElementById('size');
const quan=document.getElementById('quan');
const buttonadd=document.getElementById('add');
const shows=document.getElementById('shows');
const buttonsave=document.getElementById('save');
var total = document.getElementById('total');
const create1=document.getElementById('create1');
const colour=document.getElementById('clour')
const dname=document.getElementById('dname');
const btnaddclr=document.getElementById('save1')
const btnok=document.getElementById('save');
var i=0;var j=0;var totalsizeQty;var totalsizeQty1=0;
var Total;
function genpdf()
{
 const gen =document.getElementById('generate');  
  html2pdf(gen);
  

}
function a()
{ 
    
    document.getElementById('text1').innerHTML=(companyname.value).toUpperCase();
}
function s()
{
    document.getElementById('text2').innerHTML=(date.value);
}
function d()
{
    document.getElementById('text3').innerHTML=dcno.value;
}
function dn()
{
    document.getElementById('text10').innerHTML=(dname.value).toUpperCase();
}

function f()
{
    document.getElementById('text4').innerHTML=(stylno.value).toUpperCase();
}
function c()
{
    document.getElementById('text7').innerHTML=(colour.value).toUpperCase();
}
function g()
{
    document.getElementById('text5').innerHTML=(size.value).toUpperCase();
}
function h()
{
    document.getElementById('text6').innerHTML=(quan.value).toUpperCase();
}
function p()
{
    document.getElementById('text11').innerHTML=(tp.value).toUpperCase();
}



function myfunctionadd()
{

    
    firebase.database().ref('in/'+stylno.value+ colour.value+date.value).push({
        usersize : size.value,
        userquan : quan.value,
    }).then(()=>{
        
        firebase.database().ref('in/'+stylno.value+colour.value+date.value).on('value',(snapshot)=>{
            var i=1;
            create.innerHTML ="";
            snapshot.forEach((data) => {
                key=data.val();
                uservalue=data.val();
                uservalue=data.val();
                
                create.innerHTML +=`<tr>
                <td>${i}</td>
                
                <td>${uservalue.usersize}</td>
                <td>${uservalue.userquan}</td>
                <td>${uservalue.userquan}</td>
                </tr>`;
                i++;
            })
        })
        
        
        
        })
         totalsizeQty=0;
        var leadsRef =firebase.database().ref('in/'+stylno.value+colour.value+date.value);
        leadsRef.on('value', function(snapshot) {
            snapshot.forEach(function(childSnapshot) {
              var childData = childSnapshot.val();
              console.log(childData+"");
              //uservalue=childData.val();
              totalsizeQty=totalsizeQty+parseInt(childData.userquan);
                 document.getElementById('text11').innerHTML="TOTAL :-"+totalsizeQty;
              
                })
                
               
               
            })
            
        
            
    
        }







    function addclr()
{
    
    
    firebase.database().ref("in/"+stylno.value+ colour.value).push({
        usertotal : totalsizeQty,
    })
  
        

    firebase.database().ref('in/'+stylno.value+companyname.value).push({
        usertotal : totalsizeQty,
        userclr : colour.value,
        userdate : date.value
    })   
}

function myfunctionsave()
{


    firebase.database().ref(colour.value).push({
        usercompany : companyname.value,
        userdate : date.value,
        ustylno : stylno.value,
        udname : dname.value,
        userclr : colour.value,
       
    }).then(()=>{
        document.getElementById().innerHTML="";
    })
    
    alert('data saved sucessfully');
}


buttonadd.addEventListener('click',function(event)
{
   
    event.preventDefault();
    myfunctionadd()
    

})
buttonsave.addEventListener('click',function(event)
{
    event.preventDefault();
    myfunctionsave();
    

});
btnok.addEventListener('click',function(event)
{
    event.preventDefault();
    myfunctionsave();
    

});
btnaddclr.addEventListener('click',function (event) 
{
    event.preventDefault();
    addclr();    
});









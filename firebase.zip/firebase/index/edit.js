const stylno=document.getElementById('styleno')
const colour=document.getElementById('colour')
var shade=document.getElementById('shade')
var keyelemet;
var recordKeyElement=document.getElementById('txt_recordKey')
function editdata(recordId,key)
{
    console.log(key)
    console.log(recordId.userclrdeatils)
        
        colour.value = recordId.userclrdeatils
        shade.value = recordId.usershade
   
}
function btnsavechange()
{
    firebase.database().ref('sam/'+stylno.value).update({
        userclrdeatils : colour.value,
        usershade : shade.value

    })
}
function shadeedit()
{
    var i=0 
firebase.database().ref('sam/'+stylno.value).on('value',(snapshot)=>{
    snapshot.forEach((data) => {
    debugger
    
        show.innerHTML +=`<tr>
                
                
               <td>${data.val().userclrdeatils}</td>
                <td>${data.val().usershade}</td>
        <td><button onclick="editdata('${data._delegate.key}','`+JSON.stringify(data.val()).replaceAll('"','&quot;')
        +`')">Edit</button>
            <button onclick='deletedata(${data.val()})'>Delete</button>
            </td>
                
             </tr>`;


    })

    })
 
}



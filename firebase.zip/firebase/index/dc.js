firebase.database().ref(styln).on('value',(snapshot)=>{
    var i=1;
    create.innerHTML ="";
    snapshot.forEach((data) => {
        key=data.val();
        uservalue=data.val();
        uservalue=data.val();
        
    
        
        
    })
});